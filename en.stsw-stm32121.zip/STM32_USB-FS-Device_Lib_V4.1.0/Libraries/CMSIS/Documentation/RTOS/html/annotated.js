var annotated =
[
    [ "osMailQDef_t", "structos_mail_q_def__t.html", "structos_mail_q_def__t" ],
    [ "osMessageQDef_t", "structos_message_q_def__t.html", "structos_message_q_def__t" ],
    [ "osMutexDef_t", "structos_mutex_def__t.html", "structos_mutex_def__t" ],
    [ "osPoolDef_t", "structos_pool_def__t.html", "structos_pool_def__t" ],
    [ "osSemaphoreDef_t", "structos_semaphore_def__t.html", "structos_semaphore_def__t" ],
    [ "osThreadDef_t", "structos_thread_def__t.html", "structos_thread_def__t" ],
    [ "osTimerDef_t", "structos_timer_def__t.html", "structos_timer_def__t" ]
];